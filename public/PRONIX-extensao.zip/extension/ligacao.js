// Ligação no WhatsApp Web: o botão "Gravar ligação", a transcrição automática e a entrada da ligação no report.
//
// O inject.js (na página) acha a chamada, grava a voz do lead e a sua em partes de 3 minutos e manda cada parte
// para cá. Aqui cada parte vai para o servidor transcrever (com o tempo de cada trecho), as falas dos dois lados são
// intercaladas pelo tempo e a ligação fica guardada para a conversa em que você estava. No próximo report (ou
// resumo) desta conversa, as falas da ligação entram junto, marcadas como "[ligação]".
(function () {
  'use strict';
  if (window.__crLigacao) return;

  const GUARDAR_DIAS = 14;
  const MAX_LIGACOES = 40;
  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  const mmss = (ms) => {
    const s = Math.max(0, Math.floor(ms / 1000));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  };

  // O content.js entrega aqui o leitor de nome dele, que pula o status do topo ("online", "digitando…").
  let leitorDeNome = null;

  /** O nome da conversa aberta (o mesmo que o report usa: sem isso a ligação não entra no report do lead). */
  function nomeDaConversa() {
    if (leitorDeNome) return leitorDeNome();
    const h = document.querySelector('#main header');
    if (!h) return '';
    const t = h.querySelector('span[title]');
    const nome = (t && t.getAttribute('title')) || (h.innerText || '').split('\n').map((x) => x.trim()).find((x) => x && !/^clique|^click/i.test(x));
    return String(nome || '').trim();
  }

  // ---------------------------------------------------------------- guardar e ler
  const lerLigacoes = () => new Promise((r) => {
    try { chrome.storage.local.get({ ligacoes: [] }, (c) => r(Array.isArray(c.ligacoes) ? c.ligacoes : [])); } catch (_) { r([]); }
  });
  async function guardar(lig) {
    const corte = Date.now() - GUARDAR_DIAS * 86400000;
    const lista = (await lerLigacoes()).filter((x) => x.em >= corte && x.id !== lig.id);
    lista.push(lig);
    try { chrome.storage.local.set({ ligacoes: lista.slice(-MAX_LIGACOES) }); } catch (_) { /* sem storage */ }
  }

  /** As falas das ligações gravadas com este lead, no formato das mensagens do report. */
  async function mensagensDa(nome) {
    const alvo = norm(nome);
    if (!alvo) return [];
    const lista = (await lerLigacoes()).filter((x) => norm(x.nome) === alvo && Array.isArray(x.falas) && x.falas.length);
    const msgs = [];
    lista.sort((a, b) => a.em - b.em).forEach((lig) => {
      lig.falas.forEach((f) => msgs.push({
        from: f.quem === 'eu' ? 'eu' : 'lead',
        type: 'texto',
        content: '[ligação] ' + f.texto,
        timestamp: new Date(lig.em + Math.round(f.t * 1000)).toISOString(),
      }));
    });
    return msgs;
  }

  // ---------------------------------------------------------------- botão
  const ui = document.createElement('div');
  ui.id = 'cr-ligacao';
  ui.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483646;display:none;align-items:center;gap:8px;padding:8px 10px;border-radius:12px;background:#18171b;color:#fff;font:600 13px/1.3 system-ui,-apple-system,Segoe UI,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);max-width:360px';
  const texto = document.createElement('span');
  const botao = document.createElement('button');
  botao.type = 'button';
  botao.style.cssText = 'border:0;border-radius:8px;padding:6px 10px;font:700 13px system-ui,-apple-system,Segoe UI,sans-serif;cursor:pointer;background:#ffb800;color:#18171b';
  const fechar = document.createElement('button');
  fechar.type = 'button';
  fechar.textContent = '×';
  fechar.title = 'Esconder';
  fechar.style.cssText = 'border:0;background:transparent;color:#bbb;font-size:16px;cursor:pointer;padding:0 2px';
  ui.append(texto, botao, fechar);
  const montar = () => { if (!ui.isConnected && document.body) document.body.appendChild(ui); };

  const cmd = (c, extra) => window.postMessage({ __crLigacaoCmd: c, ...extra }, '*');
  const estado = { chamada: false, gravando: false, inicio: 0, nome: '', falas: [], pendentes: 0, parou: false, partes: 0, erros: 0, id: '', relogio: null, finalizarTimer: null, resultado: null };
  const ouvintes = [];
  const mudou = () => ouvintes.forEach((f) => { try { f(); } catch (_) { /* ignora */ } });
  // O botão no cartão do lead (content.js desenha com este id): quando existe, ele mostra o estado e o aviso do canto some.
  const botaoDoCartao = () => document.getElementById('cr-ligacao-btn');

  /** Texto e cores do botão do cartão para o estado de agora. */
  function infoCartao() {
    if (estado.gravando && estado.semVoz) return { texto: `⚠️ Sem a voz do lead · Parar ${mmss(Date.now() - estado.inicio)}`, cor: '#ffc233', borda: '#ffc233', titulo: 'Não está chegando som do lead. Pare, clique em gravar de novo e permita o áudio desta aba. Se a ligação abriu em outra janela, traga para esta aba.' };
    if (estado.gravando && estado.niveis) return { texto: `⏺ Parar ${mmss(Date.now() - estado.inicio)} · Você ${estado.niveis.eu ? '🟢' : '⚪'} Lead ${estado.niveis.lead ? '🟢' : '⚪'}`, cor: '#ff6f5c', borda: '#ff6f5c', titulo: 'Verde = chegando som daquele lado nos últimos segundos. Se alguém está falando e a bolinha dele não fica verde, confira em "Áudio da ligação".' };
    if (estado.gravando) return { texto: `⏺ Parar gravação · ${mmss(Date.now() - estado.inicio)}`, cor: '#ff6f5c', borda: '#ff6f5c', titulo: 'Gravando a ligação (a sua voz e a do lead). Clique para parar; a transcrição começa sozinha.' };
    if (estado.parou || estado.pendentes > 0) return { texto: 'Transcrevendo a ligação…', cor: '#ffc233', borda: '#ffc233', titulo: 'As partes da ligação estão sendo transcritas.' };
    if (estado.resultado && Date.now() - estado.resultado.em < 10 * 60 * 1000) {
      return { texto: estado.resultado.ok ? `✓ Ligação transcrita (${estado.resultado.falas} falas)` : 'Ligação sem transcrição', cor: estado.resultado.ok ? '#3ddc84' : '#ff6f5c', borda: estado.resultado.ok ? '#3ddc84' : '#ff6f5c', titulo: estado.resultado.ok ? 'As falas da ligação entram no próximo report desta conversa. Clique para gravar outra.' : estado.resultado.msg };
    }
    if (estado.chamada) return { texto: '🎙 Gravar ligação', cor: '#3ddc84', borda: '#3ddc84', titulo: 'Ligação em andamento: grava a sua voz e a do lead e transcreve para o report.' };
    return { texto: '🎙 Gravar ligação', cor: '#a39e93', borda: '#55515b', titulo: 'Durante uma ligação no WhatsApp Web: grava a sua voz e a do lead e transcreve para o report.' };
  }
  /** O clique no botão do cartão (ou do painel lateral). */
  function alternar() {
    if (estado.gravando) return cmd('parar');
    if (estado.parou || estado.pendentes > 0) return;
    estado.nome = nomeDaConversa();
    estado.resultado = null;
    // as escolhas já estão na memória: o pedido sai na hora do clique (o Chrome só pede a aba logo após um clique)
    cmd('gravar', { opcoes: { ...audio } });
  }

  // ---------------------------------------------------------------- entradas de áudio
  const audio = { microfone: '', fonteLead: '' }; // '' = padrão
  try { chrome.storage.local.get({ audioLigacao: {} }, (c) => Object.assign(audio, (c && c.audioLigacao) || {})); } catch (_) { /* sem storage */ }
  let painelAudio = null;

  async function listarEntradas() {
    const md = navigator.mediaDevices;
    if (!md || !md.enumerateDevices) return [];
    let lista = (await md.enumerateDevices()).filter((d) => d.kind === 'audioinput');
    if (lista.length && !lista.some((d) => d.label)) {
      // sem permissão ainda, o Chrome não mostra os nomes: pede o microfone uma vez
      try { const s = await md.getUserMedia({ audio: true }); s.getTracks().forEach((t) => t.stop()); lista = (await md.enumerateDevices()).filter((d) => d.kind === 'audioinput'); } catch (_) { /* segue sem nomes */ }
    }
    return lista.filter((d) => d.deviceId && d.deviceId !== 'default');
  }

  async function abrirAudio() {
    if (painelAudio) { painelAudio.remove(); painelAudio = null; return; }
    const caixa = document.createElement('div');
    caixa.id = 'cr-audio-painel';
    caixa.style.cssText = 'position:fixed;left:16px;bottom:72px;z-index:2147483647;width:320px;padding:14px;border-radius:12px;background:#18171b;color:#fff;font:500 13px/1.4 system-ui,-apple-system,Segoe UI,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.35)';
    painelAudio = caixa;
    const entradas = await listarEntradas().catch(() => []);
    if (painelAudio !== caixa) return;
    const titulo = document.createElement('div');
    titulo.textContent = 'Áudio da ligação';
    titulo.style.cssText = 'font-weight:700;margin-bottom:8px';
    caixa.appendChild(titulo);
    const escolha = (chave, rotulo, padrao) => {
      const l = document.createElement('label');
      l.textContent = rotulo;
      l.style.cssText = 'display:block;margin:8px 0 4px';
      const sel = document.createElement('select');
      sel.dataset.chave = chave;
      sel.style.cssText = 'width:100%;padding:6px;border-radius:8px;background:#26252a;color:#fff;border:1px solid #55515b';
      [['', padrao]].concat(entradas.map((d, i) => [d.deviceId, d.label || `Entrada ${i + 1}`])).forEach(([v, t]) => {
        const o = document.createElement('option');
        o.value = v;
        o.textContent = t;
        sel.appendChild(o);
      });
      sel.value = audio[chave] || '';
      if (sel.value !== (audio[chave] || '')) sel.value = ''; // o aparelho escolhido não está ligado agora
      sel.onchange = () => {
        audio[chave] = sel.value;
        try { chrome.storage.local.set({ audioLigacao: { ...audio } }); } catch (_) { /* sem storage */ }
      };
      l.appendChild(sel);
      caixa.appendChild(l);
    };
    escolha('microfone', 'Seu microfone (a sua voz)', 'O mesmo da ligação (padrão)');
    escolha('fonteLead', 'De onde vem a voz do lead', 'Áudio desta aba (recomendado)');
    const dica = document.createElement('div');
    dica.textContent = 'Use fone: sem ele o microfone ouve o lead e as falas se misturam. Só troque a fonte do lead se usar um cabo de áudio virtual. O fone onde você ouve é escolhido no WhatsApp ou no Mac.';
    dica.style.cssText = 'margin-top:10px;color:#bbb;font-size:12px';
    const ok = document.createElement('button');
    ok.type = 'button';
    ok.textContent = 'Pronto';
    ok.style.cssText = 'margin-top:10px;border:0;border-radius:8px;padding:7px 14px;font-weight:700;cursor:pointer;background:#ffb800;color:#18171b';
    ok.onclick = () => { caixa.remove(); painelAudio = null; };
    caixa.append(dica, ok);
    document.body.appendChild(caixa);
  }

  function mostrar(msg, rotulo, acao, cor) {
    mudou();
    if (botaoDoCartao()) { esconder(); return; }
    montar();
    texto.textContent = msg;
    botao.style.display = rotulo ? '' : 'none';
    botao.textContent = rotulo || '';
    botao.style.background = cor || '#ffb800';
    botao.style.color = cor ? '#fff' : '#18171b';
    botao.onclick = acao || null;
    ui.style.display = 'flex';
  }
  function esconder() { ui.style.display = 'none'; }
  fechar.onclick = esconder;

  function telaParado() {
    mostrar('Ligação em andamento', '🎙 Gravar ligação', alternar);
  }
  function telaGravando() {
    mostrar(`⏺ Gravando ${mmss(Date.now() - estado.inicio)}${estado.nome ? ' · ' + estado.nome : ''}`, 'Parar', () => cmd('parar'), '#c2331f');
    const tic = () => {
      const b = botaoDoCartao();
      if (b) { b.textContent = infoCartao().texto; esconder(); return; }
      montar();
      texto.textContent = `⏺ Gravando ${mmss(Date.now() - estado.inicio)}${estado.nome ? ' · ' + estado.nome : ''}`;
      ui.style.display = 'flex';
    };
    clearInterval(estado.relogio);
    estado.relogio = setInterval(tic, 1000);
  }
  function telaTranscrevendo() {
    mostrar(`Transcrevendo a ligação… ${estado.pendentes ? `(${estado.pendentes} parte(s) na fila)` : ''}`, '', null);
  }

  // ---------------------------------------------------------------- transcrição
  // Um trecho que falha (limite por minuto, rede) é perdido para sempre: tenta de novo antes de desistir.
  const ESPERAS_DE_NOVO_MS = [5000, 20000, 60000];
  function transcrever(parte, tentativa = 0) {
    if (!tentativa) estado.pendentes++;
    if (!estado.gravando) telaTranscrevendo();
    chrome.runtime.sendMessage({ action: 'transcreverLigacao', base64: parte.b64 }, (r) => {
      if (!(r && r.ok) && tentativa < ESPERAS_DE_NOVO_MS.length) {
        setTimeout(() => transcrever(parte, tentativa + 1), ESPERAS_DE_NOVO_MS[tentativa]);
        return;
      }
      estado.pendentes--;
      if (r && r.ok) {
        (r.segmentos || []).forEach((s) => {
          const t = parte.inicioMs / 1000 + (Number(s.inicio) || 0);
          if (s.texto) estado.falas.push({ quem: parte.quem, t, texto: String(s.texto).trim() });
        });
      } else {
        estado.erros++;
      }
      if (estado.parou) agendarFim();
      else if (!estado.gravando) telaTranscrevendo();
    });
  }

  function agendarFim() {
    clearTimeout(estado.finalizarTimer);
    // as últimas partes chegam logo depois do "parou" (o gravador fecha o arquivo): espera elas e a fila zerar
    estado.finalizarTimer = setTimeout(() => {
      if (estado.pendentes > 0) return telaTranscrevendo();
      finalizar();
    }, 2500);
  }

  /** Baixa a ligação como .txt (quem falou e em que minuto), para guardar ou mandar. */
  function baixarTxt(nome, inicio, juntas) {
    try {
      const d = new Date(inicio);
      const p2 = (n) => String(n).padStart(2, '0');
      const data = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
      const hora = `${p2(d.getHours())}h${p2(d.getMinutes())}`;
      const linhas = juntas.map((f) => `[${mmss(f.t * 1000)}] ${f.quem === 'eu' ? 'EU' : 'LEAD'}: ${f.texto}`);
      const conteudo = `Ligação com ${nome || 'lead'} - ${data} ${hora}\n\n${linhas.join('\n\n')}\n`;
      const url = URL.createObjectURL(new Blob([conteudo], { type: 'text/plain;charset=utf-8' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = `Ligação ${(nome || 'lead').replace(/[\\/:*?"<>|]+/g, ' ').trim()} ${data} ${hora}.txt`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    } catch (_) { /* sem download: a transcrição continua guardada */ }
  }

  async function finalizar() {
    if (!estado.parou) return;
    estado.parou = false;
    const falas = estado.falas.slice().sort((a, b) => a.t - b.t);
    // falas seguidas do mesmo lado viram uma só
    const juntas = [];
    falas.forEach((f) => {
      const ult = juntas[juntas.length - 1];
      if (ult && ult.quem === f.quem && f.t - ult.fimT < 4) {
        ult.texto += ' ' + f.texto;
        ult.fimT = f.t;
      } else {
        juntas.push({ ...f, fimT: f.t });
      }
    });
    const nome = estado.nome || nomeDaConversa();
    estado.nome = ''; // a próxima ligação pega o nome da conversa em que ela começar
    if (!juntas.length) {
      estado.resultado = { ok: false, em: Date.now(), msg: estado.erros ? 'Não consegui transcrever a ligação. Confira a chave e a conexão.' : 'A ligação ficou sem fala reconhecida.' };
      mostrar(estado.erros ? 'Não consegui transcrever a ligação. Confira a chave e a conexão.' : 'A ligação ficou sem fala reconhecida.', '', null);
      return;
    }
    estado.resultado = { ok: true, em: Date.now(), falas: juntas.length };
    await guardar({ id: estado.id, nome, em: estado.inicio, duracaoMs: estado.duracaoMs || 0, falas: juntas.map(({ quem, t, texto: tx }) => ({ quem, t: Math.round(t * 10) / 10, texto: tx })) });
    baixarTxt(nome, estado.inicio, juntas);
    if (!juntas.some((f) => f.quem === 'lead')) {
      mostrar('⚠️ A transcrição saiu SEM a voz do lead. Na próxima, permita o áudio desta aba na janela do Chrome.', 'OK', esconder);
      if (botaoDoCartao()) alert('Report PRONIX: a transcrição saiu sem a voz do lead. Na próxima, permita o áudio desta aba na janela do Chrome.');
      return;
    }
    mostrar(`Ligação transcrita: ${juntas.length} falas${nome ? ` com ${nome}` : ''}. O .txt foi baixado e ela entra no próximo report desta conversa.${estado.erros ? ` (${estado.erros} parte(s) falharam)` : ''}`, 'OK', esconder);
  }

  // ---------------------------------------------------------------- eventos da página
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data || !ev.data.__crLigacao) return;
    const d = ev.data;
    if (d.evento === 'chamada') {
      estado.chamada = true;
      if (!estado.gravando) telaParado();
    } else if (d.evento === 'semChamada') {
      estado.chamada = false;
      mudou();
      if (!estado.gravando && !estado.pendentes && !estado.parou) esconder();
    } else if (d.evento === 'gravando') {
      Object.assign(estado, { gravando: true, parou: false, inicio: d.inicio, falas: [], pendentes: 0, partes: 0, erros: 0, semVoz: false, niveis: null, id: 'lig-' + d.inicio });
      if (!estado.nome) estado.nome = nomeDaConversa();
      telaGravando();
    } else if (d.evento === 'semVozDoLead') {
      estado.semVoz = true;
      clearInterval(estado.relogio);
      mostrar('⚠️ Não estou ouvindo a voz do lead. Se ele já falou, pare e grave de novo permitindo o áudio desta aba.', 'Parar', () => cmd('parar'), '#c2331f');
      if (botaoDoCartao()) alert('Report PRONIX: não estou ouvindo a voz do lead. Se ele já falou, pare e grave de novo permitindo o áudio desta aba.');
    } else if (d.evento === 'niveis') {
      estado.niveis = { eu: Boolean(d.eu), lead: Boolean(d.lead) };
      const b = botaoDoCartao();
      if (b && estado.gravando && !estado.semVoz) b.textContent = infoCartao().texto;
    } else if (d.evento === 'vozDoLead') {
      if (estado.semVoz) { estado.semVoz = false; telaGravando(); }
      mudou();
    } else if (d.evento === 'parte') {
      transcrever(d);
    } else if (d.evento === 'parou') {
      clearInterval(estado.relogio);
      estado.gravando = false;
      estado.parou = true;
      estado.duracaoMs = d.duracaoMs;
      telaTranscrevendo();
      agendarFim();
    } else if (d.evento === 'erro') {
      estado.resultado = { ok: false, em: Date.now(), msg: d.erro || 'Não consegui gravar.' };
      if (botaoDoCartao()) { mudou(); alert(d.erro || 'Não consegui gravar.'); return; }
      mostrar(d.erro || 'Não consegui gravar.', 'OK', esconder);
    }
  });

  window.__crLigacao = { abrirAudio, mensagensDa, nomeDaConversa, usarNome: (f) => { leitorDeNome = f; }, infoCartao, alternar, aoMudar: (f) => ouvintes.push(f) };
})();
